from __future__ import annotations

import json
from cgi import FieldStorage
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parent


class PlannerHandler(SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.end_headers()

    def do_POST(self) -> None:
        if self.path != "/parse-upload":
            self.send_json({"error": "Not found"}, status=404)
            return

        try:
            form = FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={
                    "REQUEST_METHOD": "POST",
                    "CONTENT_TYPE": self.headers.get("Content-Type", ""),
                    "CONTENT_LENGTH": self.headers.get("Content-Length", "0"),
                },
            )
            upload = form["file"] if "file" in form else None
            if upload is None or not getattr(upload, "filename", ""):
                self.send_json({"error": "No file uploaded."}, status=400)
                return

            filename = upload.filename.lower()
            content = upload.file.read()
            if not filename.endswith(".xlsx"):
                self.send_json({"error": "Only .xlsx Excel files are supported. Save .xls as .xlsx and upload again."}, status=400)
                return

            rows = self.read_xlsx(content)
            self.send_json({"rows": rows, "rowCount": len(rows)})
        except Exception as exc:
            self.send_json({"error": f"Unable to parse Excel file: {exc}"}, status=400)

    def read_xlsx(self, content: bytes) -> list[list[str]]:
        workbook = load_workbook(BytesIO(content), data_only=True, read_only=True)
        sheet = workbook.active
        rows: list[list[str]] = []
        for row in sheet.iter_rows(values_only=True):
            values = ["" if value is None else str(value).strip() for value in row]
            while values and values[-1] == "":
                values.pop()
            if any(values):
                rows.append(values)
        return rows

    def send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main() -> None:
    server = ThreadingHTTPServer(("127.0.0.1", 4175), lambda *args, **kwargs: PlannerHandler(*args, directory=str(ROOT), **kwargs))
    print("Production planner running at http://127.0.0.1:4175/index.html")
    server.serve_forever()


if __name__ == "__main__":
    main()
